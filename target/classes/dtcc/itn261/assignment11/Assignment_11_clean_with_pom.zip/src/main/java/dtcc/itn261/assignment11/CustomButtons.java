package dtcc.itn261.assignment11;

import javafx.scene.control.Button;

public class CustomButtons extends Button {

    public CustomButtons() {
        super();
    }

/*    Maybe for a later date
    public CustomButtons(String text, EventHandler<ActionEvent> eventHandler) {
        super(text);
        this.setOnAction(eventHandler);
    }
*/

}

